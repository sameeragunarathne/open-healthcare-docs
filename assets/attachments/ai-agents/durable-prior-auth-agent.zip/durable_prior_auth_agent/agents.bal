import ballerina/ai;
import ballerina/workflow;

final workflow:DurableAgent priorAuthAgent = check new ({
    systemPrompt: {
        role: "Prior Authorization Agent",
        instructions: string `Check whether the requested service needs prior authorization.
            If it does, gather the clinical evidence from the patient's record, ask the care
            team for anything the payer requires that is missing, and draft a Da Vinci PAS
            request. Wait for the payer's decision and report the outcome.`
    },
    model: check ai:getDefaultModelProvider(),
    inputType: PriorAuthRequest,
    resultType: PriorAuthOutcome,
    activities: [
        fetchClinicalEvidence,
        {activity: checkCoverageRequirements, retryPolicy: {maxRetries: 3}},
        {
            activity: submitPriorAuthorization,
            approvalPolicy: {userRoles: "clinician", title: "Review the prior authorization request"}
        }
    ],
    humanTasks: {
        requestDocumentation: {
            userRoles: "care-coordinator",
            title: "Provide missing clinical documentation",
            timeout: {hours: 72}
        }
    },
    events: {
        payerDecision: {request: PayerDecision, cardinality: workflow:SINGLE_EVENT}
    }
});
