import ballerina/http;

configurable string ehrFhirUrl = "http://localhost:9090/fhir/r4";
configurable string payerApiUrl = "http://localhost:9091/payer";

final http:Client ehrFhir = check new (ehrFhirUrl);
final http:Client payerApi = check new (payerApiUrl);
