import ballerina/http;

// A stand-in for the payer's Coverage Requirements Discovery (CRD) and
// Prior Authorization Support (PAS) APIs, so the sample runs without a real payer.
service /payer on new http:Listener(9091) {

    # Coverage rules for a service. MRI codes need prior authorization.
    resource function get crd/[string payerId]/[string serviceCode]() returns CoverageRequirements {
        boolean isMri = serviceCode.startsWith("737");
        return {
            priorAuthRequired: isMri,
            requiredDocumentation: isMri
                ? ["Active diagnosis", "At least 6 weeks of conservative treatment", "Current pain score"]
                : []
        };
    }

    # Accept a PAS Claim and return the id of the pended ClaimResponse.
    resource function post pas/Claim/\$submit(@http:Payload json claim) returns string {
        return "ClaimResponse/cr-1001";
    }
}
