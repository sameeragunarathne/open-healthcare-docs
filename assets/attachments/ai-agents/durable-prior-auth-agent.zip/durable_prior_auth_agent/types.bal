# A request to start a prior authorization case.
public type PriorAuthRequest record {|
    string patientId;
    string payerId;
    string serviceCode;
    string orderingPractitioner;
|};

# Coverage requirements returned by the payer's Coverage Requirements Discovery API.
public type CoverageRequirements record {|
    boolean priorAuthRequired;
    string[] requiredDocumentation;
|};

# The payer's decision on a submitted request.
public type PayerDecision record {|
    string claimResponseId;
    "approved"|"denied"|"pended" outcome;
    string? reason = ();
|};

# The final outcome of a prior authorization case.
public type PriorAuthOutcome record {|
    string patientId;
    string serviceCode;
    "approved"|"denied"|"not-required"|"withdrawn" status;
    string? claimResponseId;
    string summary;
|};
