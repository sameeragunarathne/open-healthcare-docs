import ballerina/workflow;

# Read the patient's active conditions, recent observations, and current medications from the EHR.
#
# + patientId - FHIR id of the patient
# + return - A FHIR searchset Bundle with the clinical evidence
@workflow:Activity
function fetchClinicalEvidence(string patientId) returns json|error {
    return ehrFhir->get(string `/Condition?patient=${patientId}&clinical-status=active`);
}

# Look up the payer's coverage rules and documentation requirements for a service.
#
# + payerId - Identifier of the patient's payer
# + serviceCode - CPT or HCPCS code of the requested service
# + return - The payer's coverage requirements
@workflow:Activity
function checkCoverageRequirements(string payerId, string serviceCode) returns CoverageRequirements|error {
    return payerApi->get(string `/crd/${payerId}/${serviceCode}`);
}

# Submit a prior authorization request (Da Vinci PAS Claim) to the payer.
#
# + claim - The PAS Claim bundle drafted by the agent
# + return - The id of the payer's ClaimResponse
@workflow:Activity
function submitPriorAuthorization(json claim) returns string|error {
    return payerApi->post("/pas/Claim/$submit", claim);
}
