import ballerina/http;

service /prior\-auth on new http:Listener(8086) {

    # Start a prior authorization case. Returns at once with the case id.
    resource function post .(PriorAuthRequest request) returns record {|string caseId;|}|error {
        string caseId = check priorAuthAgent.run(
            string `Prior authorization for ${request.serviceCode}`, request);
        return {caseId};
    }

    # Deliver the payer's decision, which may arrive days later.
    resource function post [string caseId]/decision(PayerDecision decision) returns error? {
        _ = check priorAuthAgent.sendData(caseId, "payerDecision", decision);
    }

    # Read the outcome of a case.
    resource function get [string caseId]() returns PriorAuthOutcome|error {
        return priorAuthAgent.getResult(caseId);
    }
}
