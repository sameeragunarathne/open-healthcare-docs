isolated function createReviewTask(string patientId, string draft) returns string|error {
    return "task-" + patientId;
}
