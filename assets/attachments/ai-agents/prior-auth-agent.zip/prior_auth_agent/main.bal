import ballerina/http;

service /prior\-auth on new http:Listener(8085, timeout = 900) {
    resource function post assist(PriorAuthQuery query) returns string|error {
        return priorAuthAgent.run(query.message, query.sessionId);
    }
}
