public type PriorAuthQuery record {|
    string message;
    string sessionId;
|};
