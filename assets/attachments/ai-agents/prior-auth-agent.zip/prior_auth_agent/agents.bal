import ballerina/ai;
import ballerinax/ai.ollama;

configurable string fhirMcpUrl = "http://localhost:8000/mcp";
configurable string ollamaUrl = "http://localhost:11434";
configurable string ollamaModel = "qwen3:4b";

// Tools from the FHIR MCP server, backed by the WSO2 FHIR Server
final ai:McpToolKit fhirTools = check new (fhirMcpUrl, permittedTools = ["search", "read"]);

final ollama:ModelProvider model = check new (ollamaModel, ollamaUrl,
    modleParameters = {numCtx: 16384, temperature: 0.2},
    connectionConfig = {timeout: 600});

# Send a drafted prior authorization request to a clinician for review.
#
# + patientId - FHIR id of the patient
# + draft - The drafted request with its supporting clinical evidence
# + return - The id of the review task
@ai:AgentTool
isolated function requestClinicianReview(string patientId, string draft) returns string|error {
    return createReviewTask(patientId, draft);
}

final ai:Agent priorAuthAgent = check new (
    systemPrompt = {
        role: "Prior Authorization Assistant",
        instructions: string `Gather the clinical evidence for the requested service from the
            patient's FHIR record using the FHIR tools: the ServiceRequest, the Condition it
            references, the Coverage, and prior treatments (Procedure, MedicationStatement)
            and Observations. Then draft a short prior authorization request that lists the
            evidence. Never submit a request yourself. Always send the draft for clinician
            review with requestClinicianReview, then reply with the review task id. /no_think`
    },
    model = model,
    tools = [fhirTools, requestClinicianReview],
    maxIter = 10
);
